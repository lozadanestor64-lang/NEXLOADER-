# Auditoría Etapa 1 (parcial)

- Suite: README/BUILD_STATUS decían 42/42; la suite real tiene 44 scripts.
- Sin `javac`: 4 pruebas (52, 53, 55, 86) fallan por entorno, no por código. Con JDK 17+ pasan (verificado con wrapper de jdk.compiler).
- test_62 y test_64 comparaban `generated_with.nexloader` con un string; el compilador emite lista (formato Bedrock) y test_65 exige la lista. Corregidas las dos pruebas.
- Resultado: 44/44 PASS, `check_versions` PASS, lint Android 18/18 PASS, core ↔ Android sincronizados.
- APK: NO generado. Falta Android SDK, Gradle 8.13 y acceso a red (Maven/Chaquopy).
- Pruebas en Minecraft Bedrock: NO realizadas (requieren dispositivo con Minecraft).
